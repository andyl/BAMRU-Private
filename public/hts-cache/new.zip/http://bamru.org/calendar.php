<html>
	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title>BAMRU Calendar</title>
        <meta name="description" content="Bay Area Mountain Rescue Unit.">
        <meta name="keywords" content="mountain rescue, wilderness rescue, wilderness medicine, wilderness first aid, search and rescue, SAR, technical rescue, vertical rescue, cliff rescue, crevasse rescue, climbing, climbing accidents, mountaineering, backcountry skiing, glacier travel">
		
		<link rel='stylesheet' type='text/css' href='styles/style.css'>
	</head>


<body bgcolor="#FFFFFF" leftmargin="0" marginwidth="0" topmargin="0" marginheight="0">


<div align="center">
  <table width="767" cellpadding="0" cellspacing="0">
    <tr> 
      <td colspan="5" align="center"><a href="/index.html">
	    <img src="assets/logo.gif" alt="Bay Area Mountain Rescue" title="BAMRU Home" width="216" height="51" border="0"></a><br> 
 		<img src="assets/graydot.gif" height="1" width="758" border="0"></td>
    </tr>
    <tr> 
      <td width="172" valign=top rowspan="3"><a id="home" name="home"></a> <table cellpadding="6">
          <tr> 
            <td align="right" NOWRAP>
			    <font class="capsred">SERVING THE GREATER<br>SAN FRANCISCO BAY AREA<br></font>

          <img src="assets/dots.gif" width="134" height="10" border="0"><br>
          <a href="calendar.php" class="nav4" onfocus="blur();">CALENDAR</a><br>
          <a href="/blog" class="nav1" onfocus="blur();">BLOG</a><br>
          <img src="assets/dots.gif" width="134" height="10" border="0"><br>
          <a href="/index.html" class="nav1" onfocus="blur();">HOME</a><br>
          <a href="bamruinfo.html" class="nav1" onfocus="blur();">WHO WE ARE</a><br>
          <a href="join.html" class="nav1" onfocus="blur();">JOINING BAMRU</a><br>
          <a href="sgallery.html" class="nav1" onfocus="blur();">PHOTO GALLERY</a><br>
          <!--<a href="duty_sched.html" class="nav1" onfocus="blur();">DUTY OFFICERS</a><br> -->
          <a href="meeting_locations.html" class="nav1" onfocus="blur();">MEETING LOCATIONS</a><br>
          <a href="/sarlinks.html" class="nav1" onfocus="blur();">LINKS TO SAR SITES</a><br>
          <img src="assets/dots.gif" width="134" height="10" border="0"><br>
                <!--<a href="sitemap.cfm" class="nav3" onfocus="blur();">SITE MAP</a><br> -->
          <a href="donate.html" class="nav1" onfocus="blur();">DONATE</a><br>
          <a href="contact.html" class="nav1" onfocus="blur();">CONTACT US</a><br>
                <!--<a href="search.cfm" class="nav3" onfocus="blur();">SEARCH</a><br> -->
          <img src="assets/dots.gif" width="134" height="10" border="0"><br>

                <br>
                <br>
                <br>
                <br>
	       <br>
                <br>
                <br>
                <br>
                <br>
  
              <img src="assets/axe.gif" border="0"><br>
			  				<font class="quote"> 
				"Doubly happy, however,<br>
				is the man to whom<br>
				lofty mountain-tops are<br>
				within reach!"<br>
				<font class="caps">- John Muir
				<br></font></p>
				<br>
              <p>"The Beauty of the<br>
                Mountain is hidden for<br>
                all those who try to<br>
                discover it from the top,<br>
                supposing that, one way<br>
                or another, one can reach<br>
                this place directly. &nbsp;The<br>
                Beauty of the Mountain<br>
                reveals only to those who<br>
                climbed it..."<br>
                <font class="caps">- Antoine de Saint-Exupery <br>
                </font></p>
              <br><p>"So, if you cannot<br>
				understand that there<br>
				is something in man<br>
				which responds to the<br>
				challenge of this<br>
				mountain and goes out<br>
				to meet it, that the<br>
				struggle is the<br>
				struggle of life itself<br>
				upward and forever<br>
				upward, then you won't<br>
				see why we go."<br>
				<font class="caps">- George Leigh Mallory<br>1922<br></font></p>
			  <!--#include virtual="quotes.html" -->

				</td>
          </tr>
        </table>
	  </td>
	  
      <td valign="top" rowspan="3"><img src="assets/graydot.gif" height="500" width="1" border="0"></td>
      <td valign="top"><img src="images/mtn.jpg" width="423" height="136" border="0"></td>
      <td valign="top" rowspan="3"><img src="assets/graydot.gif" height="500" width="1" border="0"></td>
	  
      <td width="172" valign=top rowspan="3">
	  	<table cellpadding="6">

          <tr>
            <td NOWRAP> <p><a href="calendar.php" class="nav4" onfocus="blur();">
					2010 SCHEDULE</a><br>
                <a href="#MEETINGS" class="nav3" onfocus="blur();">MEETINGS</a><br>
                <a href="#TRAININGS" class="nav3" onfocus="blur();">TRAININGS</a><br>
                <a href="#EVENTS" class="nav3" onfocus="blur();">EVENTS</a><br>
                <!--<a href="duty_sched.html" class="nav3" onfocus="blur();">DUTY ROTATIONS</a><br> -->
                <img src="assets/dots.gif" width="134" height="10" border="0"><br>
                <a href="#" class="nav4" onfocus="blur();"></a></p>
              </td>
          </tr>
 		  <tr>
		  	<td>
                <br>
				<a name="GUEST" class="capsblue">Guest Policy</a><br>
				<font class="copy">Permission to participate in any BAMRU event is at the sole discretion of BAMRU. Selected BAMRU trainings are open to guests provided the guest has: (1) attended the general meeting preceding the training, (2) turned in a completed Sheriff's Office waiver form and been "sworn" by a designated Sheriff's official, and (3) met with the training leader and been approved by that leader as meeting any prerequisites specific to that training.  Two or three trainings during the spring recruiting drive are typically open to guests. Most other trainings are less open to guests; refer to the description of individual trainings for further information.  All events and schedules are subject to change.  </font>
				<!-- fix syntax coloring due to lone single quote above: ' -->
			</td>
		  </tr>
       </table></td>
    </tr>
    <tr> 
      <td><img src="assets/graydot.gif" height="1" width="423" border="0"></td>
    </tr>
    <tr> 
      <td valign="top" height="380"> 

		        <table cellpadding="8" bgcolor="#CC0000" width="423" height="45">
          <tr> 
            <td valign="bottom"> <font class="title1"><font style="color: #FFFFFF">Training &amp; Events<br>
              </font></font> </td>
          </tr>
        </table>
        <table cellpadding="6" bgcolor="#FFFFFF" width="423" height=400>
          <tr> 
			  <td valign="top"> <font class="caps"><font style="color: #3366CC">2010-2011 SCHEDULE</font></font><br>Our general meetings are open to the public.&nbsp; Some trainings 
					are open to guests who have attended the general meeting preceding 
					the training (see <a href="#GUEST" class="summary">Guest Policy</a> to
					the right); others are open only to BAMRU trainees and members.&nbsp; 
					See the descriptions of individual events for further information.<br><br>You may also <a href="/calendar.php?search=1" class="summary">search a date range</a>.<table cellpadding="1" cellspacing=0 bgcolor="#FFFFFF" width="406"><tr bgcolor="#FFFFFF">
  <td width=296 valign="top"><font class=summary><br>
      &nbsp; <b>Meetings</b>&nbsp; <span class="news10"><font color="#888888">7:30-9:30 PM</font></span>
      <br><br></font></td>
  <td width=75 valign="top"></td>
  <td width=35 valign="top"></td>
</tr>
<tr bgcolor="#EEEEEE">
  <td valign="top"><font class=summary>&nbsp; <a href="#GENERAL" class=summary>      General</a>
      <font class=copy>Redwood City</font></font></td>
  <td valign="top" NOWRAP><font class=summary>Nov 15<br></font></td>
  <td valign="top" NOWRAP><font class=summary></font></td>
</tr>
<tr>
  <td valign="top"><font class=summary>&nbsp; <a href="#GENERAL" class=summary>      General</a>
      <font class=copy>Castro Valley - 2011</font></font></td>
  <td valign="top" NOWRAP><font class=summary>Jan 10<br></font></td>
  <td valign="top" NOWRAP><font class=summary> 7pm open house</font></td>
</tr>
<tr bgcolor="#EEEEEE">
  <td valign="top"><font class=summary>&nbsp; <a href="#GENERAL" class=summary>      General</a>
      <font class=copy>Castro Valley </font></font></td>
  <td valign="top" NOWRAP><font class=summary>Feb 7<br></font></td>
  <td valign="top" NOWRAP><font class=summary> 7pm open house</font></td>
</tr>
<tr>
  <td valign="top"><font class=summary>&nbsp; <a href="#GENERAL" class=summary>      General</a>
      <font class=copy>Redwood City</font></font></td>
  <td valign="top" NOWRAP><font class=summary>Mar 21<br></font></td>
  <td valign="top" NOWRAP><font class=summary> 7pm open house</font></td>
</tr>
<tr bgcolor="#EEEEEE">
  <td valign="top"><font class=summary>&nbsp; <a href="#GENERAL" class=summary>      General</a>
      <font class=copy>Castro Valley</font></font></td>
  <td valign="top" NOWRAP><font class=summary>Apr 11<br></font></td>
  <td valign="top" NOWRAP><font class=summary> 7pm Open House</font></td>
</tr>
<tr>
  <td valign="top"><font class=summary>&nbsp; <a href="#GENERAL" class=summary>      General</a>
      <font class=copy>Castro Valley</font></font></td>
  <td valign="top" NOWRAP><font class=summary>May 16<br></font></td>
  <td valign="top" NOWRAP><font class=summary></font></td>
</tr>
<tr bgcolor="#FFFFFF">
  <td width=296 valign="top"><font class=summary><br>
      &nbsp; <b>Trainings</b>      <br><br></font></td>
  <td width=75 valign="top"></td>
  <td width=35 valign="top"></td>
</tr>
<tr bgcolor="#EEEEEE">
  <td valign="top"><font class=summary>&nbsp; <a href="#000220" class=summary>      Trainee Skills Day</a>
      <font class=copy>TBA</font></font></td>
  <td valign="top" NOWRAP><font class=summary>Nov 20-21<br></font></td>
  <td valign="top" NOWRAP><font class=summary>TBA</font></td>
</tr>
<tr>
  <td valign="top"><font class=summary>&nbsp; <a href="#000198" class=summary>      Winter Skills 2011</a>
      <font class=copy>Boreal</font></font></td>
  <td valign="top" NOWRAP><font class=summary>Jan 22-23<br></font></td>
  <td valign="top" NOWRAP><font class=summary>Daley</font></td>
</tr>
<tr bgcolor="#EEEEEE">
  <td valign="top"><font class=summary>&nbsp; <a href="#000232" class=summary>      AIARE Avalanche Level I Seminar </a>
      <font class=copy>Bear Valley</font></font></td>
  <td valign="top" NOWRAP><font class=summary>Jan 29-31<br></font></td>
  <td valign="top" NOWRAP><font class=summary>Schott</font></td>
</tr>
<tr>
  <td valign="top"><font class=summary>&nbsp; <a href="#000209" class=summary>      Winter Skills</a>
      <font class=copy>TBD</font></font></td>
  <td valign="top" NOWRAP><font class=summary>Feb 26-27<br></font></td>
  <td valign="top" NOWRAP><font class=summary>TBD</font></td>
</tr>
<tr bgcolor="#EEEEEE">
  <td valign="top"><font class=summary>&nbsp; <a href="#000265" class=summary>      SAR Intro and Mock Search</a>
      <font class=copy>San Mateo County</font></font></td>
  <td valign="top" NOWRAP><font class=summary>Mar 26<br></font></td>
  <td valign="top" NOWRAP><font class=summary>TBD</font></td>
</tr>
<tr>
  <td valign="top"><font class=summary>&nbsp; <a href="#000211" class=summary>      Skills Day</a>
      <font class=copy>TBD</font></font></td>
  <td valign="top" NOWRAP><font class=summary>Mar 27<br></font></td>
  <td valign="top" NOWRAP><font class=summary>TBD</font></td>
</tr>
<tr bgcolor="#EEEEEE">
  <td valign="top"><font class=summary>&nbsp; <a href="#000267" class=summary>      SAR Basic Training</a>
      <font class=copy>TBD</font></font></td>
  <td valign="top" NOWRAP><font class=summary>Apr 16-17<br></font></td>
  <td valign="top" NOWRAP><font class=summary>TBD</font></td>
</tr>
<tr>
  <td valign="top"><font class=summary>&nbsp; <a href="#000270" class=summary>      Tracking and Navigation</a>
      <font class=copy>TBD</font></font></td>
  <td valign="top" NOWRAP><font class=summary>May 21-22<br></font></td>
  <td valign="top" NOWRAP><font class=summary>TBD</font></td>
</tr>
<tr bgcolor="#FFFFFF">
  <td width=296 valign="top"><font class=summary><br>
      &nbsp; <b>Events</b>      <br><br></font></td>
  <td width=75 valign="top"></td>
  <td width=35 valign="top"></td>
</tr>
<tr bgcolor="#EEEEEE">
  <td valign="top"><font class=summary>&nbsp; <a href="#000248" class=summary>      Holiday Party</a>
      <font class=copy>Abi's</font></font></td>
  <td valign="top" NOWRAP><font class=summary>Dec 18<br></font></td>
  <td valign="top" NOWRAP><font class=summary> Rankin</font></td>
</tr>
<tr>
  <td valign="top"><font class=summary>&nbsp; <a href="#000263" class=summary>      MRA Recert</a>
      <font class=copy>Alibama Hills, Lone Pine</font></font></td>
  <td valign="top" NOWRAP><font class=summary>Mar 5<br></font></td>
  <td valign="top" NOWRAP><font class=summary>Jensen</font></td>
</tr>
<tr bgcolor="#EEEEEE">
  <td valign="top"><font class=summary>&nbsp; <a href="#000268" class=summary>      Dream Machine</a>
      <font class=copy>San Mateo County</font></font></td>
  <td valign="top" NOWRAP><font class=summary>May 7<br></font></td>
  <td valign="top" NOWRAP><font class=summary></font></td>
</tr>
<tr bgcolor="#FFFFFF">
  <td width=296 valign="top"><font class=summary><br>
      &nbsp; <b>Non-County Meetings</b>      <br><br></font></td>
  <td width=75 valign="top"></td>
  <td width=35 valign="top"></td>
</tr>
<tr bgcolor="#EEEEEE">
  <td valign="top"><font class=summary>&nbsp; <a href="#000261" class=summary>      California Region MRA</a>
      <font class=copy>Redwood City</font></font></td>
  <td valign="top" NOWRAP><font class=summary>Jan 15<br></font></td>
  <td valign="top" NOWRAP><font class=summary></font></td>
</tr>
</table><br><p><span class="capsblue"><a name="MEETINGS"></a>MEETINGS</span></p>
    <p><font class="caps"><a name="GENERAL" id="GENERAL"></a><span class="nav3">
      General Meetings</span></font><br>
      <span class="news10"> <font color="#888888">7:30-9:30 PM, see calendar for location<br>
<br></font></span>
      Our monthly general meetings are open to the public, 
						 generally on the third Monday of the month (except where that falls on
						 a holiday).&nbsp; Note there are two locations at which we alternate having meetings,
						 <a href="meeting_locations.html" class="navover">Redwood City</a>
						 and <a href="meeting_locations.html#EastBayMeeting" class="navover">Castro Valley</a>.&nbsp; 
                         Check the calendar for specific months.&nbsp; During our recruitment season, we'll be having informal Open
                         House presentations at 7:00 PM before meetings.&nbsp;<br>
    <p><font class="caps"><a name="BOD" id="BOD"></a><span class="nav3">
      Board of Directors Meetings</span></font><br>
      <span class="news10"> <font color="#888888">7:30-9:00 PM, Redwood City<br>
<br></font></span>
      Board meetings are open to BAMRU trainees and members only.<br>
    <p><font class="caps"><a name="ESB" id="ESB"></a><span class="nav3">
      Sheriff's Emergency Services Bureau Orientation</span></font><br>
      <span class="news10"> <font color="#888888">7:00-9:00 PM, Jury Assembly Room, Redwood City<br>
<br></font></span>
      This all-units ESB orientation is being put on by Sgt.&nbsp; John Diggins for
						 members and trainees of ESB units including BAMRU.&nbsp; <i>Dress is
						 full uniform.</i><br>
    <p><font class="caps"><a name="BASARC" id="BASARC"></a><span class="nav3">
      BASARC Meetings</span></font><br>
      <span class="news10"> <font color="#888888">Times and locations vary<br>
<br></font></span>
      BAMRU is a member of the <a href="http://www.basarc.org" target="_blank" class="navover">
						 Bay Area Search and Rescue Council</a>.<br>
    <p><font class="caps"><a name="CRMRA" id="CRMRA"></a><span class="nav3">
      Regional Meetings of the Mountain Rescue Association</span></font><br>
      <span class="news10"> <font color="#888888">Times and locations vary<br>
<br></font></span>
      The quarterly meeting of the <a href="http://www.crmra.org" target="_blank" class="navover">
						 California Region</a> of the <a href="http://www.mra.org" target="_blank" class="navover">
						 Mountain Rescue Association</a>.&nbsp; These meetings are open to members and
						 trainees of CRMRA teams.<br>
<p>&nbsp;</p>
<p><span class="capsblue"><a name="TRAININGS"></a>TRAININGS</span></p>
    <p><font class="caps"><a name="000220" id="000220"></a><span class="nav3">
      Trainee Skills Day</span></font><br>
      <span class="news10"> <font color="#888888">TBA<br>
November 20-21<br>      Leaders: TBA<br><br></font></span>
      Trainee packet sign off.&nbsp; An important opportunity for Trainee Members to make progress on their skills.
<br>
      <font class="caps"><img src="assets/dots.gif" width="134" height="10"></font></p>
    <p><font class="caps"><a name="000198" id="000198"></a><span class="nav3">
      Winter Skills 2011</span></font><br>
      <span class="news10"> <font color="#888888">Boreal<br>
January 22-23<br>      Leaders: Daley<br><br></font></span>
      Winter skills training.<br>
      <font class="caps"><img src="assets/dots.gif" width="134" height="10"></font></p>
    <p><font class="caps"><a name="000232" id="000232"></a><span class="nav3">
      AIARE Avalanche Level I Seminar </span></font><br>
      <span class="news10"> <font color="#888888">Bear Valley<br>
January 29-31<br>      Leaders: Schott<br><br></font></span>
      AIARE Avalanche Level I Seminar:

3 day, level 1 avalanche class (AIARE) hosted by Mountain Adventure Seminars in Bear valley.&nbsp; This is a private class for BAMRU.

Focus is on backcountry safety & hazard recognition.&nbsp; All participants gain a thorough understanding of hazard evaluation, trip planning, travel techniques and rescue skills.

Topics Covered:

    * Types and characteristics of avalanches
    * Avalanche hazards - �Red Flags�
    * An introduction to snowpack layering & metamorphosis
    * Bonding tests: compression test & rutschblock
    * Field observations techniques
    * Trip Planning and preparation
    * Route finding and travel techniques
    * Decision making and human factors
    * Companion rescue and equipment

Note: Avy-1 is a requirement to become an Technical member.
<br>
      <font class="caps"><img src="assets/dots.gif" width="134" height="10"></font></p>
    <p><font class="caps"><a name="000209" id="000209"></a><span class="nav3">
      Winter Skills</span></font><br>
      <span class="news10"> <font color="#888888">TBD<br>
February 26-27<br>      Leaders: TBD<br><br></font></span>
      Winter skills training TBD.<br>
      <font class="caps"><img src="assets/dots.gif" width="134" height="10"></font></p>
    <p><font class="caps"><a name="000265" id="000265"></a><span class="nav3">
      SAR Intro and Mock Search</span></font><br>
      <span class="news10"> <font color="#888888">San Mateo County<br>
March 26<br>      Leaders: TBD<br><br></font></span>
      Introduction to Search and Rescue with BAMRU in San Mateo county.<br>
      <font class="caps"><img src="assets/dots.gif" width="134" height="10"></font></p>
    <p><font class="caps"><a name="000211" id="000211"></a><span class="nav3">
      Skills Day</span></font><br>
      <span class="news10"> <font color="#888888">TBD<br>
March 27<br>      Leaders: TBD<br><br></font></span>
      Skills Day.&nbsp; TBD.<br>
      <font class="caps"><img src="assets/dots.gif" width="134" height="10"></font></p>
    <p><font class="caps"><a name="000267" id="000267"></a><span class="nav3">
      SAR Basic Training</span></font><br>
      <span class="news10"> <font color="#888888">TBD<br>
April 16-17<br>      Leaders: TBD<br><br></font></span>
      Intensive weekend training to orient prospective members on the basic skills required to contribute effectively to search and rescue operations.&nbsp;  Intended for people with no prior SAR experience.<br>
      <font class="caps"><img src="assets/dots.gif" width="134" height="10"></font></p>
    <p><font class="caps"><a name="000270" id="000270"></a><span class="nav3">
      Tracking and Navigation</span></font><br>
      <span class="news10"> <font color="#888888">TBD<br>
May 21-22<br>      Leaders: TBD<br><br></font></span>
      Tracking and Navigation typically cover two days: one day of Tracking and one day of Navigation/Skills sign offs.&nbsp; <br>
<p>&nbsp;</p>
<p><span class="capsblue"><a name="EVENTS"></a>EVENTS</span></p>
    <p><font class="caps"><a name="000248" id="000248"></a><span class="nav3">
      Holiday Party</span></font><br>
      <span class="news10"> <font color="#888888">Abi's<br>
December 18<br>      Leaders: Abi Rankin<br><br></font></span>
      BAMRU's annual holiday party.&nbsp; <br>
      <font class="caps"><img src="assets/dots.gif" width="134" height="10"></font></p>
    <p><font class="caps"><a name="000263" id="000263"></a><span class="nav3">
      MRA Recert</span></font><br>
      <span class="news10"> <font color="#888888">Alibama Hills, Lone Pine<br>
March 5<br>      Leaders: Jensen<br><br></font></span>
      Cal MRA Recertification 2011: Technical Rock.&nbsp; 

Hosted by Ventura County in the Alabama Hills near Lone Pine.

Details: www.crmra.org/recert_2011<br>
      <font class="caps"><img src="assets/dots.gif" width="134" height="10"></font></p>
    <p><font class="caps"><a name="000268" id="000268"></a><span class="nav3">
      Dream Machine</span></font><br>
      <span class="news10"> <font color="#888888">San Mateo County<br>
May 7<br><br></font></span>
      BAMRU often works with the County of San Mateo to provide support services at public events:

www.miramarevents.com/dreammachines<br>
<p>&nbsp;</p>
<p><span class='capsblue'>EMERGENCY SERVICES BUREAU CALENDAR</span></p>BAMRU is one of several specialized units comprising the San Mateo Sheriff's Office<a href='http://www.co.sanmateo.ca.us/portal/site/sheriffs/menuitem.b7e419e678ddeb0274452b31d17332a0/?vgnextoid=9609dd7c41211210VgnVCM1000001d37230aRCRD&cpsextcurrchannel=1' class='navover'>Emergency Services Bureau</a> (ESB).&nbsp; The full<a href='http://www.google.com/calendar/embed?src=9tgs9ebm67lij6b4b07vi3fbak@group.calendar.google.com&ctz=America/Los_Angeles' class='navover'>ESB Calendar</a> shows BAMRU events along with those of other units.<br>			  
          </tr>
		  
        </table>
		
	  </td>
	</tr>
  </table>
  <br>
  <font class="copy">&copy; Copyright 2004-2010 Bay Area Mountain Rescue. &nbsp;Photo by Dan Herman.</font><br><br><br>


</div>


</body>
</html>
